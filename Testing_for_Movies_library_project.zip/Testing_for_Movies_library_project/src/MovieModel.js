var app = window.app || {};

app.Models = app.Models || {};

app.Models.Movie = Backbone.Model.extend({
    

    defaults: function () {

        return {
            name: 'Pushpa',
            rating: '4.5',
            genre:'comedy',
            comment:'good'
        };
    },
    
    names:function(){
        return this.get('name')
    },

    rating:function(){
        return this.get('rating')
    },

    ishorrormovie:function(){
        if(this.get('genres')=='horror'){
            return true
        }
        else{
            return false
        }
    },
    iscomedymovie:function(){
        if(this.get('genres')=='comedy'){
            return true
        }
        else{
            return false
        }
    },
    isactionmovie:function(){
        if(this.get('genres')=='action'){
            return true
        }
        else{
            return false
        }
    },
    isadventuremovie:function(){
        if(this.get('genres')=='adventure'){
            return true
        }
        else{
            return false
        }
    }

});
